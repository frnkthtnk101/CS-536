CG_hw5.txt
Franco Pettigrosso

features of the program:
for a more detailed description of what is going on 
look at source code.

read of parameters to create a robot arm.
outputs a iv file - the final output is formatted to work with free cad.

Language - python(3.6)

OS used - MacOS Catlina

interpreter - python(3.6)

starting point - bash CG_hw5

other files:
CG_hw5.py - this is where the main is at
