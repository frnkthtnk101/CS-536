CG_hw2.txt
Franco Pettigrosso

features of the progroam:
for a more detailed description of what is going on 
look at source code.

reads in a file - the program can take in a file of 3d points delimited by a [space]
creates a arbitrary curve - converts those points into a curvy line
outputs a iv file - the final output is formatted to work with free cad.

Language - python(3.6)

OS used - MacOS Catlina

interpreter - python(3.6)

starting point - bash CG_hw2

other files:
cpts_int.txt - the default if no file is given
