CG_hw4.txt
Franco Pettigrosso

features of the program:
for a more detailed description of what is going on 
look at source code.

read of parameters to create a Superellipsoid
outputs a iv file - the final output is formatted to work with free cad.

Language - python(3.6)

OS used - MacOS Catlina

interpreter - python(3.6)

starting point - bash CG_hw4

other files:
CG_hw4.py - this is where the main is at


normalized points are calculated at line 181 - 196